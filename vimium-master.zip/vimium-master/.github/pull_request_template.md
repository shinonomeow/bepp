## Description

Provide a rationale for this PR, and a reference to the corresponding issue, if there is one.

Please review the "Which pull requests get merged?" section in `CONTRIBUTING.md`.
